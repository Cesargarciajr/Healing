from django.contrib import admin
from .models import Especialidades, DadosMedico, DatasAbertas, Consulta, Documento

admin.site.register(Especialidades)
admin.site.register(DadosMedico)
admin.site.register(DatasAbertas)
admin.site.register(Consulta)
admin.site.register(Documento)

 